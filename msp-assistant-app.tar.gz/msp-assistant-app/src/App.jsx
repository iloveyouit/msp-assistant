import React, { useState, useRef, useEffect } from 'react';
import { Send, Terminal, Cloud, FileText, Zap, Loader2, Upload, Download, Database, History, X, Save } from 'lucide-react';

export default function App() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: '👋 **MSP Operations Assistant Pro Ready**\n\nI can help you with:\n- Azure VM & Entra ID troubleshooting\n- PowerShell automation scripts\n- Windows Server diagnostics\n- Incident analysis & documentation\n- Log file analysis (upload Event Logs, IIS logs, etc.)\n- Auto-log incidents to Notion\n- Current Microsoft KB article research\n\nWhat are you working on?',
      timestamp: new Date().toISOString()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [savedConversations, setSavedConversations] = useState([]);
  const [currentConversationName, setCurrentConversationName] = useState('');
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load saved conversations from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('msp_conversations');
    if (saved) {
      setSavedConversations(JSON.parse(saved));
    }
  }, []);

  const systemPrompt = `You are an expert MSP Operations Assistant specializing in:
- Azure infrastructure (VMs, Entra ID, networking, Update Management)
- Windows Server administration and troubleshooting
- PowerShell automation for MSP environments
- Active Directory and hybrid identity
- Incident response and documentation
- Log file analysis (Windows Event Logs, IIS logs, Application logs)

When responding:
1. Provide clear, actionable troubleshooting steps
2. Generate PowerShell scripts with proper error handling
3. Reference current Microsoft documentation when relevant
4. Format responses professionally for MSP documentation
5. Ask clarifying questions when needed (client name, error messages, environment details)
6. When analyzing logs, identify critical errors, warnings, and patterns
7. After resolving incidents, offer to log them to Notion with full details

User context: Rob Loftin, Senior IT Infrastructure Consultant at Long View Systems (143IT), managing 500+ endpoints and 600+ servers across hybrid Azure/on-prem environments for MSP clients including GR Energy, McLeod, Deer Park, Canes Midstream, and Lab Central.

Available clients: GR Energy, McLeod, Deer Park, Canes Midstream, Lab Central.`;

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Check file size (max 5MB for text files)
    if (file.size > 5 * 1024 * 1024) {
      alert('File too large. Please upload files under 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      const content = e.target.result;
      setUploadedFile({ name: file.name, content, type: file.type });
      
      // Auto-send message with file
      const fileMessage = `I've uploaded a file: **${file.name}**\n\nPlease analyze this log file and identify any critical issues, errors, or patterns.`;
      setInput(fileMessage);
    };
    
    if (file.type.includes('text') || file.name.endsWith('.log') || file.name.endsWith('.txt') || file.name.endsWith('.csv')) {
      reader.readAsText(file);
    } else {
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = { 
      role: 'user', 
      content: input,
      timestamp: new Date().toISOString(),
      file: uploadedFile ? { name: uploadedFile.name } : null
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Build messages array with file content if present
      let conversationMessages = [...messages.filter(m => m.role !== 'system'), userMessage];
      
      // If there's an uploaded file, prepend it to the user's message
      if (uploadedFile) {
        conversationMessages[conversationMessages.length - 1].content = 
          `${input}\n\n--- FILE CONTENT: ${uploadedFile.name} ---\n${uploadedFile.content.substring(0, 10000)}\n--- END FILE ---`;
      }

      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 4000,
          system: systemPrompt,
          messages: conversationMessages,
          tools: [
            {
              type: 'web_search_20250305',
              name: 'web_search'
            }
          ],
          mcp_servers: [
            {
              type: 'url',
              url: 'https://mcp.notion.com/mcp',
              name: 'notion'
            }
          ]
        })
      });

      const data = await response.json();
      
      // Extract all content blocks
      let assistantContent = '';
      for (const block of data.content) {
        if (block.type === 'text') {
          assistantContent += block.text;
        } else if (block.type === 'tool_use') {
          if (block.name === 'web_search') {
            assistantContent += `\n\n🔍 *Searching: ${block.input.query}*\n`;
          } else {
            assistantContent += `\n\n📝 *${block.name}*\n`;
          }
        } else if (block.type === 'mcp_tool_result') {
          // MCP tool results handled in next API call
          assistantContent += '\n✅ *Action completed*\n';
        }
      }

      const assistantMessage = {
        role: 'assistant', 
        content: assistantContent.trim(),
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setUploadedFile(null); // Clear uploaded file after sending
    } catch (error) {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `❌ Error: ${error.message}\n\nPlease try again or rephrase your question.`,
        timestamp: new Date().toISOString()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const saveConversation = () => {
    if (!currentConversationName.trim()) {
      alert('Please enter a conversation name');
      return;
    }

    const conversation = {
      id: Date.now(),
      name: currentConversationName,
      messages: messages,
      timestamp: new Date().toISOString()
    };

    const updated = [...savedConversations, conversation];
    setSavedConversations(updated);
    localStorage.setItem('msp_conversations', JSON.stringify(updated));
    setShowSaveDialog(false);
    setCurrentConversationName('');
    alert('Conversation saved successfully!');
  };

  const loadConversation = (conversation) => {
    setMessages(conversation.messages);
    setShowHistory(false);
  };

  const deleteConversation = (id) => {
    const updated = savedConversations.filter(c => c.id !== id);
    setSavedConversations(updated);
    localStorage.setItem('msp_conversations', JSON.stringify(updated));
  };

  const exportToMarkdown = () => {
    let markdown = `# MSP Operations Assistant - Conversation Export\n\n`;
    markdown += `**Date:** ${new Date().toLocaleString()}\n\n`;
    markdown += `---\n\n`;

    messages.forEach(msg => {
      const role = msg.role === 'user' ? '👤 **You**' : '🤖 **Assistant**';
      const time = msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString() : '';
      markdown += `### ${role} ${time ? `(${time})` : ''}\n\n`;
      markdown += `${msg.content}\n\n`;
      markdown += `---\n\n`;
    });

    const blob = new Blob([markdown], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `msp-conversation-${new Date().toISOString().split('T')[0]}.md`;
    a.click();
    setShowExportMenu(false);
  };

  const exportToDocx = async () => {
    alert('DOCX export coming soon! For now, use Markdown export.');
    setShowExportMenu(false);
  };

  const quickActions = [
    { icon: Cloud, label: 'Azure VM Issue', prompt: 'Help me troubleshoot an Azure VM that\'s not responding' },
    { icon: Terminal, label: 'PowerShell Script', prompt: 'Generate a PowerShell script to check disk space across multiple servers' },
    { icon: FileText, label: 'Incident Report', prompt: 'Help me document an incident for a client' },
    { icon: Zap, label: 'AD Password Reset', prompt: 'Walk me through password reset troubleshooting in AD' }
  ];

  const formatMessage = (content) => {
    return content
      .split('\n')
      .map((line, i) => {
        if (line.startsWith('```')) {
          return null;
        }
        if (line.startsWith('# ')) {
          return <h2 key={i} className="text-xl font-bold mt-4 mb-2">{line.slice(2)}</h2>;
        }
        if (line.startsWith('## ')) {
          return <h3 key={i} className="text-lg font-semibold mt-3 mb-2">{line.slice(3)}</h3>;
        }
        if (line.startsWith('- ')) {
          return <li key={i} className="ml-4">{line.slice(2)}</li>;
        }
        if (line.startsWith('**') && line.endsWith('**')) {
          return <p key={i} className="font-semibold mt-2">{line.slice(2, -2)}</p>;
        }
        if (line.includes('✅') || line.includes('❌') || line.includes('🔍') || line.includes('📝')) {
          return <p key={i} className="text-blue-300 italic mb-2">{line}</p>;
        }
        return <p key={i} className="mb-2">{line}</p>;
      });
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      {/* Header */}
      <div className="bg-slate-800/50 backdrop-blur border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-500 p-2 rounded-lg">
              <Terminal className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold">MSP Operations Assistant Pro</h1>
              <p className="text-sm text-slate-400">Azure • PowerShell • Windows Server • Log Analysis • Notion Integration</p>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
              title="Upload log file"
            >
              <Upload className="w-4 h-4" />
              <span className="text-sm">Upload</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFileUpload}
              accept=".log,.txt,.csv,.evtx"
              className="hidden"
            />
            
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
              title="View saved conversations"
            >
              <History className="w-4 h-4" />
              <span className="text-sm">History</span>
            </button>
            
            <button
              onClick={() => setShowSaveDialog(true)}
              className="flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
              title="Save conversation"
            >
              <Save className="w-4 h-4" />
              <span className="text-sm">Save</span>
            </button>
            
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="flex items-center gap-2 px-3 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-colors"
                title="Export conversation"
              >
                <Download className="w-4 h-4" />
                <span className="text-sm">Export</span>
              </button>
              
              {showExportMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-slate-800 rounded-lg shadow-xl border border-slate-700 z-50">
                  <button
                    onClick={exportToMarkdown}
                    className="w-full text-left px-4 py-2 hover:bg-slate-700 rounded-t-lg"
                  >
                    📄 Export as Markdown
                  </button>
                  <button
                    onClick={exportToDocx}
                    className="w-full text-left px-4 py-2 hover:bg-slate-700 rounded-b-lg"
                  >
                    📝 Export as DOCX
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* History Sidebar */}
      {showHistory && (
        <div className="absolute right-0 top-20 w-80 h-[calc(100vh-5rem)] bg-slate-800 border-l border-slate-700 z-40 overflow-y-auto">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Saved Conversations</h3>
              <button onClick={() => setShowHistory(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {savedConversations.length === 0 ? (
              <p className="text-slate-400 text-sm">No saved conversations yet.</p>
            ) : (
              <div className="space-y-2">
                {savedConversations.map(conv => (
                  <div key={conv.id} className="bg-slate-700 p-3 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 cursor-pointer" onClick={() => loadConversation(conv)}>
                        <p className="font-semibold text-sm">{conv.name}</p>
                        <p className="text-xs text-slate-400">
                          {new Date(conv.timestamp).toLocaleString()}
                        </p>
                        <p className="text-xs text-slate-400 mt-1">
                          {conv.messages.length} messages
                        </p>
                      </div>
                      <button
                        onClick={() => deleteConversation(conv.id)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Save Dialog */}
      {showSaveDialog && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-slate-800 p-6 rounded-lg w-96 border border-slate-700">
            <h3 className="text-lg font-semibold mb-4">Save Conversation</h3>
            <input
              type="text"
              value={currentConversationName}
              onChange={(e) => setCurrentConversationName(e.target.value)}
              placeholder="Enter conversation name..."
              className="w-full bg-slate-700 text-white placeholder-slate-400 rounded-lg px-4 py-2 mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
              onKeyPress={(e) => e.key === 'Enter' && saveConversation()}
            />
            <div className="flex gap-2">
              <button
                onClick={saveConversation}
                className="flex-1 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg"
              >
                Save
              </button>
              <button
                onClick={() => setShowSaveDialog(false)}
                className="flex-1 bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      {messages.length === 1 && (
        <div className="px-6 py-4 bg-slate-800/30">
          <p className="text-sm text-slate-400 mb-3">Quick Actions:</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {quickActions.map((action, idx) => (
              <button
                key={idx}
                onClick={() => setInput(action.prompt)}
                className="flex items-center gap-2 px-3 py-2 bg-slate-700/50 hover:bg-slate-700 rounded-lg transition-colors text-sm"
              >
                <action.icon className="w-4 h-4 text-blue-400" />
                <span>{action.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-3xl rounded-lg px-4 py-3 ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800/70 text-slate-100'
              }`}
            >
              {msg.file && (
                <div className="mb-2 text-xs bg-slate-900/50 px-2 py-1 rounded">
                  📎 {msg.file.name}
                </div>
              )}
              {msg.role === 'assistant' ? (
                <div className="prose prose-invert prose-sm max-w-none">
                  {msg.content.split('```').map((part, i) => {
                    if (i % 2 === 1) {
                      return (
                        <pre key={i} className="bg-slate-900 p-3 rounded-lg overflow-x-auto mt-2 mb-2">
                          <code className="text-sm text-green-400">{part}</code>
                        </pre>
                      );
                    }
                    return <div key={i}>{formatMessage(part)}</div>;
                  })}
                </div>
              ) : (
                <p>{msg.content}</p>
              )}
              {msg.timestamp && (
                <p className="text-xs opacity-50 mt-2">
                  {new Date(msg.timestamp).toLocaleTimeString()}
                </p>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-800/70 rounded-lg px-4 py-3 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
              <span className="text-slate-300">Analyzing...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* File Upload Indicator */}
      {uploadedFile && (
        <div className="px-6 py-2 bg-blue-900/30 border-t border-blue-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-400" />
              <span className="text-sm">File ready: {uploadedFile.name}</span>
            </div>
            <button
              onClick={() => setUploadedFile(null)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Input */}
      <div className="bg-slate-800/50 backdrop-blur border-t border-slate-700 px-6 py-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Describe your issue, upload logs, or ask for help..."
            className="flex-1 bg-slate-700 text-white placeholder-slate-400 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isLoading}
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:cursor-not-allowed px-6 py-3 rounded-lg transition-colors flex items-center gap-2"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
        <p className="text-xs text-slate-500 mt-2">
          💡 Try: "Azure VM performance issue" • Upload Event Logs • "Create Notion incident for SQL outage" • "Export this chat"
        </p>
      </div>
    </div>
  );
}
